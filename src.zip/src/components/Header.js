import logo from '../images/logo.png'
import {Link} from "react-router-dom";
function Header() {
    return (
        <div className="header">
            <img src={logo} alt=""/>
            <div className="header__links">
                <Link to={'/'} className="header__links-item">О колледже</Link>
                <Link to={'/stud'} className="header__links-item">Студенту</Link>
                <Link to={'/abit'} className="header__links-item">Абитуриенту</Link>
                <Link to={'/schedule'} className="header__links-item">Расписание</Link>
                <Link to={'/contacts'} className="header__links-item">Контакты</Link>
                <Link to={'/news'} className="header__links-item">Новости</Link>
            </div>
            <div className="header__btn">
                Контакты
            </div>
        </div>
    );
}

export default Header;
